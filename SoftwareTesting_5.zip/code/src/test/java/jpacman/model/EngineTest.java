package jpacman.model;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import jpacman.TestUtils;
import org.junit.Before;
import org.junit.Test;

import org.mockito.Mockito;

import java.lang.reflect.Field;

import static org.mockito.ArgumentMatchers.endsWith;
import static org.mockito.ArgumentMatchers.nullable;
import static org.mockito.Mockito.when;

/**
 * Systematic testing of the game state transitions.
 *
 * The test makes use of the simple map and its containing monsters
 * and players, as defined in the GameTestCase.
 * <p>
 *
 * @author Arie van Deursen; Aug 5, 2003
 * @version $Id: EngineTest.java,v 1.6 2008/02/04 23:00:12 arie Exp $
 */
public class EngineTest extends GameTestCase {

    /**
     * The engine that we'll push along every possible transition.
     */
    private Engine theEngine;


    /**
     * Set up an Engine, making use of the Game object
     * (with a small map containing all sorts of guests)
     * created in the superclass.
     */
    @Before public void setUp() {
        theEngine = new Engine(theGame);
        assertTrue(theEngine.inStartingState());
    }

     // Create state model test cases.
     @Test public void addTestCasesHere() {}

    @Test
    public void testInvariantKillsMutant() {
        Engine mockEngine = Mockito.spy(Engine.class);
        when(mockEngine.inStartingState()).thenReturn(true);
        when(mockEngine.inPlayingState()).thenReturn(true);
        assertFalse(mockEngine.invariant());
    }

    @Test
    public void testStartKillsMutant() {
        Engine realEngine = new Engine();
        Engine mockEngine = Mockito.spy(realEngine);
        when(mockEngine.inStartingState()).thenReturn(false);
        when(mockEngine.inGameOverState()).thenReturn(true);
        when(mockEngine.inDiedState()).thenReturn(true);

        if (TestUtils.assertionsEnabled()) {
            boolean assertCatch;
            try {
                mockEngine.start();
                assertCatch = false;
            } catch (AssertionError ae) {
                assertCatch = true;
            }
            assertTrue(assertCatch);
        }
    }

    @Test
    public void testInWonStateKillsMutant() {
        Game mockGame = Mockito.mock(Game.class);
        when(mockGame.initialized()).thenReturn(true);
        Engine mockEngine = Mockito.spy(new Engine(mockGame));
        when(mockEngine.inStartingState()).thenReturn(true);
        when(mockEngine.invariant()).thenReturn(true);
        when(mockGame.playerWon()).thenReturn(true);
        assertFalse(mockEngine.inWonState());
    }

    @Test
    public void testInDiedStateKillsMutant() {
        Game mockGame = Mockito.mock(Game.class);
        when(mockGame.initialized()).thenReturn(true);
        Engine mockEngine = Mockito.spy(new Engine(mockGame));
        when(mockEngine.inStartingState()).thenReturn(true);
        when(mockEngine.invariant()).thenReturn(true);
        when(mockGame.playerDied()).thenReturn(true);
        assertFalse(mockEngine.inDiedState());
    }


    @Test
    public void testInGameOverStateKillsMutant() {
        Engine mockEngine = Mockito.spy(new Engine());
        when(mockEngine.inDiedState()).thenReturn(true);
        when(mockEngine.inWonState()).thenReturn(false);
        assertTrue(mockEngine.inGameOverState());
    }

    @Test
    public void testInStartingStateKillsMutant() {
        Game mockGame = Mockito.mock(Game.class);
        when(mockGame.initialized()).thenReturn(true);
        Engine mockEngine = Mockito.spy(new Engine(mockGame));
        when(mockGame.playerDied()).thenReturn(false);
        when(mockGame.playerWon()).thenReturn(true);
        assertFalse(mockEngine.inStartingState());
    }

    @Test
    public void testInvariantKillsMutants() { // Kills mutant 1 and 20
        Engine mockEngine = Mockito.spy(Engine.class);
        when(mockEngine.inStartingState()).thenReturn(false);
        when(mockEngine.inPlayingState()).thenReturn(false);
        when(mockEngine.inHaltedState()).thenReturn(false);
        when(mockEngine.inDiedState()).thenReturn(false);
        when(mockEngine.inWonState()).thenReturn(true);
        assertTrue(mockEngine.invariant());
    }

    @Test
    public void testInvariantKillsAllMutantsInvalid() { // Kills mutant 21, 22
        Engine mockEngine = Mockito.spy(Engine.class);
        when(mockEngine.inStartingState()).thenReturn(false);
        when(mockEngine.inPlayingState()).thenReturn(false);
        when(mockEngine.inHaltedState()).thenReturn(true);
        when(mockEngine.inDiedState()).thenReturn(true);
        when(mockEngine.inWonState()).thenReturn(true);
        assertTrue(mockEngine.invariant());
    }
}
