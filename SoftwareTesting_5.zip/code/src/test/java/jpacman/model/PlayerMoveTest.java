package jpacman.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

import org.junit.Test;
import org.mockito.Mockito;

/**
 * Specialize the general MoveTest test suite to one
 * that is tailored to PlayerMoves.
 * Thanks to inheritance, all test cases from MoveTest
 * are also methods in PlayerMoveTest, thus helping us
 * to test conformance with Liskov's Substitution Principle (LSP)
 * of the Move hierarchy.
 * <p>
 * @author Arie van Deursen; August 21, 2003.
 * @version $Id: PlayerMoveTest.java,v 1.8 2008/02/10 19:51:11 arie Exp $
 */
public class PlayerMoveTest extends MoveTest {

    /**
     * The move the player would like to make.
     */
    private PlayerMove aPlayerMove;

    /**
     * Simple test of a few getters.
     */
    @Test
    public void testSimpleGetters() {
        PlayerMove playerMove = new PlayerMove(thePlayer, foodCell);
        assertEquals(thePlayer, playerMove.getPlayer());
        assertTrue(playerMove.movePossible());
        assertFalse(playerMove.playerDies());
        assertEquals(1, playerMove.getFoodEaten());
        assertTrue(playerMove.invariant());
    }


    /**
     * Create a move object that will be tested.
     *  @see jpacman.model.MoveTest#createMove(jpacman.model.Cell)
     *  @param target The cell to be occupied by the move.
     *  @return The move to be tested.
     */
    @Override
    protected PlayerMove createMove(Cell target) {
        aPlayerMove = new PlayerMove(thePlayer, target);
        return aPlayerMove;
    }

    // kills mutant Player:1, Player:3
    @Test
    public void testMeetPlayer() {
        Player mockPlayer = Mockito.spy(Player.class);
        Cell currentCell = theGame.getBoard().getCell(0, 1);
        Cell targetCell = theGame.getBoard().getCell(1, 1);

        when(mockPlayer.getLocation()).thenReturn(currentCell);

        String message = "";
        try {
            Move move = new PlayerMove(mockPlayer, targetCell);
        } catch (AssertionError ae) {
            message = ae.getMessage();
        }
        assertEquals("Move: only one player supported", message);
    }

    // kills mutant Player:4, and PlayerMove:7
    @Test
    public void testMoveToFoodCell() {
        PlayerMove playerMove = createMove(foodCell);

        assertTrue(foodCell.getInhabitant() instanceof Food);
        assertEquals(Guest.FOOD_TYPE, foodCell.getInhabitant().guestType());

        assertTrue(playerMove.movePossible());
        boolean failureGenerated = false;
        try {
            playerMove.apply();
        } catch (AssertionError ae) {
            failureGenerated = true;
        }
        assertFalse(failureGenerated);
        assertFalse(playerMove.playerDies());
        assertEquals(1, playerMove.getFoodEaten());
        assertEquals(1, thePlayer.getPointsEaten());
    }

    // kills mutant Player:5
    @Test
    public void testPlayerInvariant() {
        Player mockPlayer = Mockito.spy(Player.class);
        when(mockPlayer.guestInvariant()).thenReturn(false);
        assertFalse(mockPlayer.playerInvariant());
    }

    // kills mutant PlayerMove:4, PlayerMove:5, PlayerMove:6
    @Test
    public void testInvariant() {
        PlayerMove mockPlayerMove = Mockito.spy(new PlayerMove(thePlayer, foodCell));
        when(mockPlayerMove.moveInvariant()).thenReturn(false);
        assertFalse(mockPlayerMove.invariant());
    }
}
