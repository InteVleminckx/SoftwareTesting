package jpacman.model;

import org.junit.Test;
import org.mockito.Mockito;

import static org.junit.Assert.assertFalse;
import static org.mockito.Mockito.when;

public class FoodTest extends GuestTest {

    // kills mutant Food:4
    @Test
    public void testFoodInvariant() {
        Food mockFood = Mockito.spy(Food.class);
        when(mockFood.guestInvariant()).thenReturn(false);
        assertFalse(mockFood.foodInvariant());

    }

}
